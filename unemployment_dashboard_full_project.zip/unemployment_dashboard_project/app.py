from flask import Flask, render_template, jsonify, request
from pathlib import Path
import pandas as pd
import math

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

def clean_columns(df):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"].astype(str).str.strip(),
                                    dayfirst=True, errors="coerce")
    if "Region" in df.columns:
        df["Region"] = df["Region"].astype(str).str.strip()
    if "Area" in df.columns:
        df["Area"] = df["Area"].astype(str).str.strip()
    return df

def load_data():
    files = list(DATA_DIR.glob("*.csv"))
    if not files:
        raise FileNotFoundError("No CSV dataset found inside the data folder.")
    frames = []
    for file in files:
        frame = pd.read_csv(file)
        frame = clean_columns(frame)
        frame["Source File"] = file.name
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True, sort=False)
    return combined

def safe_number(value):
    if pd.isna(value) or value is None:
        return None
    if isinstance(value, (int, float)):
        if not math.isfinite(float(value)):
            return None
        return round(float(value), 2)
    return value

def records_to_json(frame):
    output = []
    for record in frame.to_dict(orient="records"):
        clean = {}
        for key, value in record.items():
            if isinstance(value, pd.Timestamp):
                clean[key] = value.strftime("%Y-%m-%d") if not pd.isna(value) else None
            elif pd.isna(value) if not isinstance(value, (list, dict)) else False:
                clean[key] = None
            else:
                clean[key] = safe_number(value)
        output.append(clean)
    return output

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/summary")
def summary():
    df = load_data()
    rate_col = "Estimated Unemployment Rate (%)"
    employed_col = "Estimated Employed"
    region_col = "Region"

    avg_rate = float(df[rate_col].dropna().mean()) if rate_col in df else 0
    total_employed = float(df[employed_col].dropna().sum()) if employed_col in df else 0
    regions = int(df[region_col].nunique()) if region_col in df else 0

    by_region = (
        df.dropna(subset=[rate_col])
        .groupby(region_col)[rate_col]
        .mean()
        .sort_values(ascending=False)
        .head(10)
    )

    by_date = (
        df.dropna(subset=["Date", rate_col])
        .groupby("Date")[rate_col]
        .mean()
        .sort_index()
    )

    return jsonify({
        "total_records": int(len(df)),
        "average_unemployment_rate": round(avg_rate, 2),
        "total_employed_sum": round(total_employed, 2),
        "regions": regions,
        "top_regions": [{"region": str(k), "rate": round(float(v), 2)}
                        for k, v in by_region.items()],
        "monthly_trend": [{"date": k.strftime("%Y-%m-%d"), "rate": round(float(v), 2)}
                          for k, v in by_date.items()]
    })

@app.route("/api/regions")
def regions():
    df = load_data()
    region_col = "Region"
    rate_col = "Estimated Unemployment Rate (%)"
    result = (
        df.dropna(subset=[rate_col])
        .groupby(region_col)
        .agg(
            average_rate=(rate_col, "mean"),
            minimum_rate=(rate_col, "min"),
            maximum_rate=(rate_col, "max"),
            records=(rate_col, "count")
        )
        .reset_index()
        .sort_values("average_rate", ascending=False)
    )
    result["average_rate"] = result["average_rate"].round(2)
    result["minimum_rate"] = result["minimum_rate"].round(2)
    result["maximum_rate"] = result["maximum_rate"].round(2)
    return jsonify(records_to_json(result))

@app.route("/api/data")
def data():
    df = load_data()
    selected_region = request.args.get("region", "").strip()
    area = request.args.get("area", "").strip()
    limit = min(max(int(request.args.get("limit", 100)), 1), 1000)

    if selected_region:
        df = df[df["Region"].astype(str).str.strip() == selected_region]
    if area and "Area" in df.columns:
        df = df[df["Area"].astype(str).str.strip() == area]

    columns = [c for c in [
        "Region", "Date", "Frequency",
        "Estimated Unemployment Rate (%)",
        "Estimated Employed",
        "Estimated Labour Participation Rate (%)",
        "Area", "Region.1", "longitude", "latitude"
    ] if c in df.columns]

    return jsonify({
        "total": int(len(df)),
        "rows": records_to_json(df[columns].head(limit))
    })

@app.route("/api/health")
def health():
    try:
        df = load_data()
        return jsonify({"status": "ok", "records": int(len(df))})
    except Exception as exc:
        return jsonify({"status": "error", "message": str(exc)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
