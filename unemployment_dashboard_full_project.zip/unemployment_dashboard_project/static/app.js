let trendChart;
let regionChart;

async function getJSON(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error("Backend request failed: " + response.status);
  return response.json();
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString("en-IN", {maximumFractionDigits: 2});
}

async function checkHealth() {
  try {
    const data = await getJSON("/api/health");
    document.getElementById("healthStatus").textContent = "Backend online";
    document.getElementById("healthStatus").style.background = "#2e7d5b";
  } catch (error) {
    document.getElementById("healthStatus").textContent = "Backend error";
    document.getElementById("healthStatus").style.background = "#b42318";
    console.error(error);
  }
}

async function loadSummary() {
  try {
    const data = await getJSON("/api/summary");
    document.getElementById("totalRecords").textContent = formatNumber(data.total_records);
    document.getElementById("averageRate").textContent = data.average_unemployment_rate + "%";
    document.getElementById("regionCount").textContent = formatNumber(data.regions);
    document.getElementById("employmentSum").textContent = formatNumber(data.total_employed_sum);

    const trendLabels = data.monthly_trend.map(x => x.date);
    const trendValues = data.monthly_trend.map(x => x.rate);
    if (trendChart) trendChart.destroy();
    trendChart = new Chart(document.getElementById("trendChart"), {
      type: "line",
      data: { labels: trendLabels, datasets: [{ label: "Average unemployment %", data: trendValues, tension: .25 }] },
      options: { responsive: true, maintainAspectRatio: true }
    });

    const regionLabels = data.top_regions.map(x => x.region);
    const regionValues = data.top_regions.map(x => x.rate);
    if (regionChart) regionChart.destroy();
    regionChart = new Chart(document.getElementById("regionChart"), {
      type: "bar",
      data: { labels: regionLabels, datasets: [{ label: "Average unemployment %", data: regionValues }] },
      options: { indexAxis: "y", responsive: true, maintainAspectRatio: true }
    });
  } catch (error) {
    console.error(error);
    alert("Unable to load dashboard summary. Check that Flask is running.");
  }
}

async function loadRegions() {
  try {
    const rows = await getJSON("/api/regions");
    document.getElementById("regionTable").innerHTML = rows.map(row => `
      <tr>
        <td>${row.Region}</td>
        <td>${row.average_rate}</td>
        <td>${row.minimum_rate}</td>
        <td>${row.maximum_rate}</td>
        <td>${row.records}</td>
      </tr>`).join("");
  } catch (error) { console.error(error); }
}

async function loadData() {
  const region = encodeURIComponent(document.getElementById("regionFilter").value);
  const area = encodeURIComponent(document.getElementById("areaFilter").value);
  try {
    const data = await getJSON(`/api/data?region=${region}&area=${area}&limit=100`);
    document.getElementById("dataCount").textContent = `Showing ${Math.min(data.total, 100)} of ${data.total} matching records.`;
    if (!data.rows.length) {
      document.getElementById("dataHead").innerHTML = "";
      document.getElementById("dataBody").innerHTML = "<tr><td>No records found.</td></tr>";
      return;
    }
    const columns = Object.keys(data.rows[0]);
    document.getElementById("dataHead").innerHTML = "<tr>" + columns.map(c => `<th>${c}</th>`).join("") + "</tr>";
    document.getElementById("dataBody").innerHTML = data.rows.map(row =>
      "<tr>" + columns.map(c => `<td>${row[c] ?? ""}</td>`).join("") + "</tr>"
    ).join("");
  } catch (error) { console.error(error); }
}

checkHealth();
loadSummary();
loadRegions();
loadData();
