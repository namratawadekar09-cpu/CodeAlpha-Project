# India Unemployment Dashboard

A complete frontend + backend data analytics project built with Flask and Pandas.

## 1. Project structure

```text
unemployment_dashboard_project/
|-- app.py
|-- requirements.txt
|-- README.md
|-- data/
|   |-- Unemployment in India.csv
|   |-- Unemployment_Rate_upto_11_2020.csv
|-- templates/
|   |-- index.html
|-- static/
    |-- style.css
    |-- app.js
```

## 2. Requirements

- Python 3.10 or newer
- VS Code
- Internet connection for Chart.js CDN

## 3. Run in VS Code

Open the project folder in VS Code.

Open the terminal and run:

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Install libraries:

```bash
pip install -r requirements.txt
```

Start the backend:

```bash
python app.py
```

Open this address in your browser:

```text
http://127.0.0.1:5000
```

## 4. Features

- Dashboard summary cards
- Average unemployment rate
- Total dataset record count
- Region count
- Monthly average trend chart
- Regional comparison chart
- Regional analysis table
- Dataset search by region
- Rural/Urban filter where available
- Backend health endpoint
- Automatic loading of CSV files from the data folder

## 5. API endpoints

- `GET /api/health`
- `GET /api/summary`
- `GET /api/regions`
- `GET /api/data`
- `GET /api/data?region=Karnataka&area=Urban`

## 6. Important note

The supplied files contain unemployment data. This project therefore implements an unemployment analytics dashboard. It does not claim to be an Iris flower classification project.
